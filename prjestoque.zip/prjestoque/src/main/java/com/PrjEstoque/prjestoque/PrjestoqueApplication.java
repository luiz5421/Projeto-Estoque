package com.PrjEstoque.prjestoque;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjestoqueApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjestoqueApplication.class, args);
	}

}
