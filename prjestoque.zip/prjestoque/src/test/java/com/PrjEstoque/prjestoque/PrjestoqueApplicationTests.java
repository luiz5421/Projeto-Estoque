package com.PrjEstoque.prjestoque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjestoqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
